package cz.casovac.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int DEVICE_COUNT = 3;
    private static final String PREFS = "timer_devices";
    private static final String SERVICE_TYPE = "_http._tcp.";

    private SharedPreferences prefs;
    private LinearLayout root;
    private WebView webView;
    private View homeView;
    private NsdManager nsdManager;
    private NsdManager.DiscoveryListener discoveryListener;
    private WifiManager.MulticastLock multicastLock;
    private AlertDialog discoveryDialog;
    private final Map<String, FoundDevice> foundDevices = new LinkedHashMap<>();
    private final String[] defaultNames = {"Časovač 1", "Časovač 2", "Časovač 3"};

    private static class FoundDevice {
        final String serviceName;
        final String host;
        final int port;
        FoundDevice(String serviceName, String host, int port) {
            this.serviceName = serviceName;
            this.host = host;
            this.port = port;
        }
        String url() { return "http://" + host + (port == 80 ? "" : ":" + port); }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(238, 243, 249));
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        nsdManager = (NsdManager) getSystemService(Context.NSD_SERVICE);
        WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        multicastLock = wifi.createMulticastLock("CasovacMdnsLock");
        multicastLock.setReferenceCounted(false);
        showHome();
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int color, int strokeColor, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeColor != Color.TRANSPARENT) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackground(rounded(Color.rgb(8, 121, 232), Color.TRANSPARENT, 13));
        b.setPadding(dp(12), dp(5), dp(12), dp(5));
        return b;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void showHome() {
        if (webView != null) {
            if (webView.getParent() instanceof ViewGroup) ((ViewGroup) webView.getParent()).removeView(webView);
            webView.destroy();
            webView = null;
        }
        root = vertical();
        root.setBackgroundColor(Color.rgb(238, 243, 249));
        root.setPadding(dp(16), dp(18), dp(16), dp(16));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("◷  Moje časovače", 25, Color.rgb(16, 27, 50), true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView count = text("ESP8266", 13, Color.rgb(8, 121, 232), true);
        header.addView(count);
        root.addView(header);

        TextView subtitle = text("Vyber zařízení nebo vyhledej časovače v místní Wi-Fi síti.", 14, Color.rgb(92, 108, 128), false);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.setMargins(0, dp(8), 0, dp(16));
        root.addView(subtitle, subParams);

        for (int i = 0; i < DEVICE_COUNT; i++) addDeviceCard(i);

        Button scan = button("⌕  Vyhledat ESP8266 v síti");
        scan.setTextSize(16);
        LinearLayout.LayoutParams scanParams = new LinearLayout.LayoutParams(-1, dp(54));
        scanParams.setMargins(0, dp(8), 0, dp(10));
        root.addView(scan, scanParams);
        scan.setOnClickListener(v -> startDiscovery());

        TextView note = text("Automatické vyhledávání používá mDNS. Zařízení musí inzerovat HTTP službu; návod na drobnou úpravu ESP8266 je v přiloženém README.", 12, Color.rgb(105, 117, 132), false);
        note.setLineSpacing(dp(2), 1f);
        root.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.addView(root);
        homeView = scroll;
        setContentView(scroll);
    }

    private void addDeviceCard(int index) {
        String name = prefs.getString("name" + index, defaultNames[index]);
        String url = prefs.getString("url" + index, "");
        LinearLayout card = vertical();
        card.setPadding(dp(14), dp(13), dp(14), dp(13));
        card.setBackground(rounded(Color.WHITE, Color.rgb(205, 222, 240), 18));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(11));
        root.addView(card, cp);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = text("◷", 25, Color.rgb(8, 121, 232), true);
        top.addView(icon, new LinearLayout.LayoutParams(dp(38), -2));
        LinearLayout labels = vertical();
        labels.addView(text(name, 18, Color.rgb(16, 27, 50), true));
        labels.addView(text(url.isEmpty() ? "Není nastaveno" : url, 12, Color.rgb(105, 117, 132), false));
        top.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        TextView number = text("" + (index + 1), 13, Color.rgb(8, 121, 232), true);
        top.addView(number);
        card.addView(top);

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.setMargins(0, dp(10), 0, 0);
        card.addView(actions, ap);
        Button configure = button("Nastavit");
        configure.setBackground(rounded(Color.rgb(231, 241, 252), Color.TRANSPARENT, 11));
        configure.setTextColor(Color.rgb(8, 100, 190));
        actions.addView(configure);
        configure.setOnClickListener(v -> configureDevice(index, name, url, null));
        Button open = button("Otevřít");
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-2, -2);
        op.setMargins(dp(8), 0, 0, 0);
        actions.addView(open, op);
        open.setEnabled(!url.isEmpty());
        if (url.isEmpty()) open.setAlpha(0.45f);
        open.setOnClickListener(v -> openDevice(url));
    }

    private void configureDevice(int slot, String oldName, String oldUrl, FoundDevice found) {
        LinearLayout form = vertical();
        form.setPadding(dp(4), dp(4), dp(4), 0);
        EditText nameInput = new EditText(this);
        nameInput.setSingleLine(true);
        nameInput.setHint("Název, např. Zahrada");
        nameInput.setText(found == null ? oldName : oldName);
        form.addView(nameInput);
        EditText addressInput = new EditText(this);
        addressInput.setSingleLine(true);
        addressInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addressInput.setHint("IP nebo adresa, např. 192.168.1.50");
        addressInput.setText(found == null ? oldUrl : found.url());
        form.addView(addressInput);
        new AlertDialog.Builder(this)
                .setTitle("Nastavení časovače " + (slot + 1))
                .setView(form)
                .setNegativeButton("Zrušit", null)
                .setNeutralButton("Vymazat", (d, w) -> {
                    prefs.edit().remove("url" + slot).putString("name" + slot, defaultNames[slot]).apply();
                    showHome();
                })
                .setPositiveButton("Uložit", (d, w) -> {
                    String n = nameInput.getText().toString().trim();
                    String u = normalizeUrl(addressInput.getText().toString().trim());
                    if (n.isEmpty()) n = defaultNames[slot];
                    if (u.isEmpty()) {
                        Toast.makeText(this, "Zadej IP adresu nebo název zařízení.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    prefs.edit().putString("name" + slot, n).putString("url" + slot, u).apply();
                    showHome();
                }).show();
    }

    private String normalizeUrl(String input) {
        if (input == null) return "";
        String s = input.trim();
        if (s.isEmpty()) return "";
        if (!s.contains("://")) s = "http://" + s;
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        if (!(s.startsWith("http://") || s.startsWith("https://"))) return "";
        return s;
    }

    private void openDevice(String url) {
        String target = normalizeUrl(url);
        if (target.isEmpty()) {
            Toast.makeText(this, "Nejdříve nastav adresu zařízení.", Toast.LENGTH_SHORT).show();
            return;
        }
        LinearLayout page = vertical();
        page.setBackgroundColor(Color.WHITE);
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(8), dp(4), dp(8), dp(4));
        toolbar.setBackgroundColor(Color.rgb(238, 243, 249));
        Button back = button("‹ Zpět");
        back.setBackground(rounded(Color.rgb(231, 241, 252), Color.TRANSPARENT, 10));
        back.setTextColor(Color.rgb(8, 100, 190));
        toolbar.addView(back);
        TextView address = text(target, 12, Color.rgb(70, 85, 105), false);
        address.setSingleLine(true);
        address.setPadding(dp(10), 0, 0, 0);
        toolbar.addView(address, new LinearLayout.LayoutParams(0, -2, 1));
        page.addView(toolbar);
        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        page.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) Toast.makeText(MainActivity.this, "Zařízení není dostupné. Zkontroluj Wi-Fi a IP adresu.", Toast.LENGTH_LONG).show();
            }
        });
        page.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(page);
        back.setOnClickListener(v -> showHome());
        webView.loadUrl(target);
    }

    private void startDiscovery() {
        if (nsdManager == null) {
            Toast.makeText(this, "Vyhledávání mDNS není v tomto zařízení dostupné.", Toast.LENGTH_LONG).show();
            return;
        }
        foundDevices.clear();
        TextView message = text("Hledám ESP8266 s HTTP službou v místní Wi-Fi síti…", 15, Color.rgb(40, 55, 75), false);
        message.setPadding(dp(8), dp(12), dp(8), dp(12));
        discoveryDialog = new AlertDialog.Builder(this)
                .setTitle("Vyhledávání zařízení")
                .setView(message)
                .setNeutralButton("Zobrazit nalezená", (d, w) -> showFoundList())
                .setNegativeButton("Zavřít", (d, w) -> stopDiscovery())
                .create();
        discoveryDialog.setOnCancelListener(d -> stopDiscovery());
        discoveryDialog.show();
        discoveryDialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> showFoundList());
        try { multicastLock.acquire(); } catch (Exception ignored) { }
        discoveryListener = new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String regType) { }
            @Override public void onServiceFound(NsdServiceInfo service) {
                String n = service.getServiceName() == null ? "" : service.getServiceName();
                String lower = n.toLowerCase(Locale.ROOT);
                if (!(lower.contains("esp8266") || lower.contains("casovac") || lower.contains("časovač"))) return;
                nsdManager.resolveService(service, new NsdManager.ResolveListener() {
                    @Override public void onResolveFailed(NsdServiceInfo serviceInfo, int errorCode) { }
                    @Override public void onServiceResolved(NsdServiceInfo serviceInfo) {
                        InetAddress address = serviceInfo.getHost();
                        if (address == null) return;
                        FoundDevice f = new FoundDevice(serviceInfo.getServiceName(), address.getHostAddress(), serviceInfo.getPort());
                        runOnUiThread(() -> showFoundDevice(f));
                    }
                });
            }
            @Override public void onServiceLost(NsdServiceInfo service) { }
            @Override public void onDiscoveryStopped(String serviceType) { }
            @Override public void onStartDiscoveryFailed(String serviceType, int errorCode) {
                runOnUiThread(() -> {
                    stopDiscovery();
                    Toast.makeText(MainActivity.this, "Vyhledávání se nepodařilo spustit (" + errorCode + ").", Toast.LENGTH_LONG).show();
                });
            }
            @Override public void onStopDiscoveryFailed(String serviceType, int errorCode) {
                try { nsdManager.stopServiceDiscovery(this); } catch (Exception ignored) { }
            }
        };
        nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener);
        message.postDelayed(() -> {
            if (discoveryDialog != null && discoveryDialog.isShowing() && foundDevices.isEmpty()) {
                message.setText("Zatím nic nenalezeno. Ověř, že ESP8266 inzeruje mDNS HTTP službu. Můžeš také nastavit IP ručně.");
            }
        }, 7000);
    }

    private void showFoundDevice(FoundDevice device) {
        String key = device.host + ":" + device.port;
        if (foundDevices.containsKey(key)) return;
        foundDevices.put(key, device);
        if (discoveryDialog == null || !discoveryDialog.isShowing()) return;
        ArrayList<String> labels = new ArrayList<>();
        for (FoundDevice f : foundDevices.values()) labels.add(f.serviceName + "\n" + f.url());
        String[] choices = labels.toArray(new String[0]);
        discoveryDialog.setMessage("Nalezeno zařízení: " + device.serviceName + "\n" + device.url() + "\nCelkem: " + foundDevices.size());
    }

    private void showFoundList() {
        if (foundDevices.isEmpty()) {
            Toast.makeText(this, "Zatím nebylo nalezeno žádné zařízení.", Toast.LENGTH_SHORT).show();
            return;
        }
        ArrayList<FoundDevice> devices = new ArrayList<>(foundDevices.values());
        String[] choices = new String[devices.size()];
        for (int i = 0; i < devices.size(); i++) {
            FoundDevice f = devices.get(i);
            choices[i] = f.serviceName + "\n" + f.url();
        }
        new AlertDialog.Builder(this)
                .setTitle("Nalezená ESP8266")
                .setItems(choices, (dialog, which) -> {
                    FoundDevice selected = devices.get(which);
                    stopDiscovery();
                    chooseSlotForFound(selected);
                })
                .setNegativeButton("Zpět", null)
                .show();
    }

    private void chooseSlotForFound(FoundDevice found) {
        String[] slots = new String[DEVICE_COUNT];
        for (int i = 0; i < DEVICE_COUNT; i++) {
            String n = prefs.getString("name" + i, defaultNames[i]);
            String u = prefs.getString("url" + i, "");
            slots[i] = (i + 1) + ". " + n + (u.isEmpty() ? " (volné)" : " (přepsat)");
        }
        new AlertDialog.Builder(this)
                .setTitle("Kam uložit nalezené zařízení?")
                .setItems(slots, (d, which) -> {
                    String suggested = found.serviceName;
                    suggested = suggested.replace('_', ' ').replace('-', ' ').trim();
                    configureDevice(which, suggested, "", found);
                })
                .setNegativeButton("Zrušit", null)
                .show();
    }

    private void stopDiscovery() {
        if (discoveryListener != null) {
            try { nsdManager.stopServiceDiscovery(discoveryListener); } catch (Exception ignored) { }
            discoveryListener = null;
        }
        if (multicastLock != null && multicastLock.isHeld()) {
            try { multicastLock.release(); } catch (Exception ignored) { }
        }
        if (discoveryDialog != null && discoveryDialog.isShowing()) discoveryDialog.dismiss();
        discoveryDialog = null;
    }

    @Override public void onBackPressed() {
        if (webView != null) {
            if (webView.canGoBack()) webView.goBack();
            else showHome();
        } else {
            super.onBackPressed();
        }
    }

    @Override protected void onDestroy() {
        stopDiscovery();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
